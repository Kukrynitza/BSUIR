#include "search_intersection.hpp"
#include <vector>
#include <algorithm>
#include "keynodes/search_keynodes.hpp"
using namespace std;

vector<SearchIntersectionGraph::versh> SearchIntersectionGraph::getIntersectionGraph(vector<versh> graph_1, vector<versh> graph_2, vector<versh> result)
{
    
    for (auto element_1 : graph_1)
    {
        for (auto element_2 : graph_2)
        {
            if (element_1.addres.Hash() == element_2.addres.Hash())
            {
                versh temp;
                temp.addres = element_1.addres;
                vector<ScAddr> vershin;
                for (auto element1 : element_1.related)
                {
                    for (auto element2 : element_2.related)
                    {
                        if (element1.Hash() == element2.Hash())
                        {
                            if (std::find(vershin.begin(), vershin.end(), element1) == vershin.end())
                            {
                                vershin.push_back(element1);
                            }
                        }
                    }
                }

                temp.related = vershin;
                result.push_back(temp);
            }
        }
    }
    return result;
}
ScAddr SearchIntersectionGraph ::GetActionClass() const
{
    return SearchKeynodes::action_search_intersection;
}
ScResult SearchIntersectionGraph ::DoProgram(ScAction &action)
{
    auto const &[SetAddr1, SetAddr2] = action.GetArguments<2>();
    if (!m_context.IsElement(SetAddr1) || !m_context.IsElement(SetAddr2))
    {
        SC_AGENT_LOG_ERROR("Graph is not specified");
        return action.FinishWithError();
    }

    ScIterator3Ptr const it3_1 = m_context.CreateIterator3(
        SetAddr1,
        ScType::EdgeAccessConstPosPerm,
        ScType::NodeConst);
    ScIterator3Ptr const it3_2 = m_context.CreateIterator3(
        SetAddr2,
        ScType::EdgeAccessConstPosPerm,
        ScType::NodeConst);
    vector<versh> graph_1;
    vector<versh> graph_2;

    while (it3_1->Next())
    {
        if (m_context.GetElementType(it3_1->Get(2)) == ScType::NodeConstClass)
            continue;
        SC_AGENT_LOG_INFO("it3_1 start");
        versh temp;
        vector<ScAddr> spis1;
        temp.addres = it3_1->Get(2);

 ScIterator5Ptr const it3_1_1 = m_context.CreateIterator5(
            temp.addres,
            ScType::EdgeUCommonConst,
            ScType::NodeConst,
            ScType::EdgeAccessConstPosPerm,
            SetAddr1);
        while (it3_1_1->Next())
        {
            SC_AGENT_LOG_INFO("it3_1_1 start");
            temp.related.push_back(it3_1_1->Get(2));
        }
        graph_1.push_back(temp);
    }
    SC_AGENT_LOG_INFO("it3_1 end");
    while (it3_2->Next())
    {
        if (m_context.GetElementType(it3_2->Get(2)) == ScType::NodeConstClass)
            continue;
        versh temp;
        vector<ScAddr> spis2;
        SC_AGENT_LOG_INFO("it3_2 start");
        temp.addres = it3_2->Get(2);
        SC_AGENT_LOG_INFO("it3_2_1 start");
         ScIterator5Ptr const it3_2_1 = m_context.CreateIterator5(
            temp.addres,
            ScType::EdgeUCommonConst,
            ScType::NodeConst,
            ScType::EdgeAccessConstPosPerm,
            SetAddr2);
        while (it3_2_1->Next())
        {
            temp.related.push_back(it3_2_1->Get(2));
        }
        graph_2.push_back(temp);
    }

    SC_AGENT_LOG_INFO("it3_2 end");
    SC_AGENT_LOG_INFO("graph_2");

    for (int i = 0; i < graph_1.size(); ++i)
    {
        versh temp = graph_1[i];

        SC_AGENT_LOG_INFO("addres");
        string const &systemIdtf2 = m_context.GetElementSystemIdentifier(temp.addres);
        SC_AGENT_LOG_INFO(systemIdtf2);
        SC_AGENT_LOG_INFO(temp.addres.Hash());
        SC_AGENT_LOG_INFO("related");
        for (int j = 0; j < temp.related.size(); ++j)
        {
            string const &systemIdtf1 = m_context.GetElementSystemIdentifier(temp.related[j]);
            SC_AGENT_LOG_INFO(systemIdtf1);
            SC_AGENT_LOG_INFO(temp.related[j].Hash());
        }
    }

    SC_AGENT_LOG_INFO("graph_2");

    for (int i = 0; i < graph_2.size(); ++i)
    {
        versh temp = graph_2[i];

        SC_AGENT_LOG_INFO("addres");
        string const &systemIdtf2 = m_context.GetElementSystemIdentifier(temp.addres);
        SC_AGENT_LOG_INFO(systemIdtf2);
        SC_AGENT_LOG_INFO(temp.addres.Hash());
        SC_AGENT_LOG_INFO("related");
        for (int j = 0; j < temp.related.size(); ++j)
        {
            string const &systemIdtf1 = m_context.GetElementSystemIdentifier(temp.related[j]);
            SC_AGENT_LOG_INFO(systemIdtf1);
            SC_AGENT_LOG_INFO(temp.related[j].Hash());
        }
    }

    vector<versh> result_graph;

    SC_AGENT_LOG_INFO("IntersectionGraph");

    result_graph = getIntersectionGraph(graph_1, graph_2, result_graph);

    for (int i = 0; i < result_graph.size(); ++i)
    {
        versh temp = result_graph[i];

        SC_AGENT_LOG_INFO("addres");
        string const &systemIdtf2 = m_context.GetElementSystemIdentifier(temp.addres);
        SC_AGENT_LOG_INFO(systemIdtf2);
        SC_AGENT_LOG_INFO(temp.addres.Hash());
        SC_AGENT_LOG_INFO("related");
        for (int j = 0; j < temp.related.size(); ++j)
        {
            string const &systemIdtf1 = m_context.GetElementSystemIdentifier(temp.related[j]);
            SC_AGENT_LOG_INFO(systemIdtf1);
            SC_AGENT_LOG_INFO(temp.related[j].Hash());
        }
    }
    ScStructure structure = m_context.GenerateStructure();
    ScStructure result_structure = m_context.GenerateStructure();
    for (auto element_1 : result_graph)
    {
        result_structure << element_1.addres;
        for (auto element_1_1 : element_1.related)
        {
            if (element_1.addres.Hash() != element_1_1.Hash())
            {
                ScAddr conected_versh = m_context.GenerateConnector(
                    ScType::EdgeUCommonConst,
                    element_1.addres,
                    element_1_1);
                result_structure << conected_versh;
            }
        }
    }

ScAddr intersectionClass = m_context.HelperResolveSystemIdtf("concept_intersection_graph");
ScAddr intersectionEdge = m_context.CreateEdge(
                ScType::EdgeAccessConstPosPerm,
                intersectionClass,
                result_structure
            );
            if (intersectionEdge.IsValid()) {
                structure.Append(intersectionEdge); 
                structure.Append(intersectionClass); 
            }
ScAddr conected_1 = m_context.GenerateConnector(
                    ScType::EdgeAccessConstPosPerm,
                    SetAddr1,
                    result_structure);
ScAddr conected_2 = m_context.GenerateConnector(
                    ScType::EdgeAccessConstPosPerm,
                    SetAddr2,
                    result_structure);
    structure.Append(SetAddr1);
    structure.Append(SetAddr2);
    structure.Append(result_structure);
    structure.Append(conected_1);
    structure.Append(conected_2);
    action.SetResult(structure);
    return action.FinishSuccessfully();
}