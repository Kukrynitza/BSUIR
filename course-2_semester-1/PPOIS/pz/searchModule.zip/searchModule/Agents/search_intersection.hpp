#pragma once

#include <sc-memory/sc_memory.hpp>
#include <sc-memory/sc_agent.hpp>
#include <vector>

using namespace std;


class SearchIntersectionGraph : public ScActionInitiatedAgent
{
public:

    struct versh
{
      ScAddr addres;
      std::vector<ScAddr> related;  
};
    vector<SearchIntersectionGraph::versh> getIntersectionGraph(vector<versh> graph_1, vector<versh> graph_2, vector<versh> result);

    ScAddr GetActionClass() const override;

    ScResult DoProgram(ScAction & action) override;

};

