#include "search_module.hpp"

#include "Agents/search_intersection.hpp"

SC_MODULE_REGISTER(SearchModule)
  ->Agent<SearchIntersectionGraph>();