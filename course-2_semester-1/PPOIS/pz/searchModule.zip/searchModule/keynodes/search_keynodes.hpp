#pragma once

#include <sc-memory/sc_keynodes.hpp>


class SearchKeynodes : public ScKeynodes
{
public:
    static inline ScKeynode const action_search_intersection{"action_search_intersection", ScType::NodeConstClass};
};